import mysql.connector
import qrcode
import getpass
from PIL import Image
import webcolors
import time
import os
from datetime import datetime, timedelta
from qrcode.image.styledpil import StyledPilImage
from qrcode.image.styles.moduledrawers import (
    GappedSquareModuleDrawer,
    RoundedModuleDrawer,
    CircleModuleDrawer,
    VerticalBarsDrawer,
    HorizontalBarsDrawer,
)

# Connect to the MySQL database
cnx = mysql.connector.connect(host='localhost', user='root', password='Jlt1935@#', database='emp')

# Create a cursor to interact with the database
cursor = cnx.cursor()

# Prepare the INSERT statement
insert_query = "INSERT INTO signup (Signup_ID, User_name, First_name, Last_name, Age, M_number, Address, Email_ID, Password, Con_pass) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"

# Function to generate and delete temporary QR code
def generate_and_delete_qr_code_with_logo(data, expiration_time, logo_path, filename, module_drawer=None):
    # Convert fill_color to RGB format
    fill_color = input("Enter the fill color (in hex format, e.g., #FF0000) or color name: ")

    try:
        # Try to interpret the fill color as a hex color code
        color_rgb = tuple(int(fill_color[i:i + 2], 16) for i in (1, 3, 5))
    except ValueError:
        try:
            # Try to interpret the fill color as a color name
            color_rgb = webcolors.name_to_rgb(fill_color)
        except ValueError:
            print("Invalid color input!")
            return

    # Generate the QR code
    qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_H, box_size=10, border=4)
    qr.add_data(data)
    qr.make(fit=True)

    # Generate an image from the QR code with the specified module_drawer
    qr_image = qr.make_image(fill_color=fill_color, back_color="white", image_factory=StyledPilImage, module_drawer=module_drawer)

    # Resize the QR code image
    qr_image = qr_image.resize((300, 300))

    # Open the logo image
    logo_image = Image.open(logo_path)

    # Apply the user-defined color to the QR code pixels
    for x in range(qr_image.size[0]):
        for y in range(qr_image.size[1]):
            r, g, b = qr_image.getpixel((x, y))
            if r == 0 and g == 0 and b == 0:  # Check if pixel is black
                qr_image.putpixel((x, y), color_rgb)  # Set pixel color to user-defined color

    # Calculate the position to place the logo at the center
    logo_size = 62
    logo_position = ((300 - logo_size) // 2, (300 - logo_size) // 2)
    logo_image = logo_image.resize((logo_size, logo_size))

    # Paste the logo on the QR code image
    qr_image.paste(logo_image, logo_position)

    # Save the image file
    qr_image.save(filename)
    print("Temporary QR code generated and saved.")

    # Calculate deletion time
    deletion_time = datetime.now() + timedelta(seconds=expiration_time)
    print(f"Temporary QR code will be deleted on: {deletion_time}")

    # Wait for the expiration time
    time.sleep(expiration_time)

    # Delete the QR code file
    os.remove(filename)
    print("Temporary QR code deleted.")

# Function to generate QR code and save it as an image file with a logo
def generate_qr_code_with_logo(data, filename, qr_size, logo_path, module_drawer=None):
    # Convert fill_color to RGB format
    fill_color = input("Enter the fill color (in hex format, e.g., #FF0000) or color name: ")

    try:
        # Try to interpret the fill color as a hex color code
        color_rgb = tuple(int(fill_color[i:i + 2], 16) for i in (1, 3, 5))
    except ValueError:
        try:
            # Try to interpret the fill color as a color name
            color_rgb = webcolors.name_to_rgb(fill_color)
        except ValueError:
            print("Invalid color input!")
            return

    # Generate the QR code
    qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_H, box_size=10, border=4)
    qr.add_data(data)
    qr.make(fit=True)

    # Generate an image from the QR code with the specified module_drawer
    qr_image = qr.make_image(fill_color=fill_color, back_color="white", image_factory=StyledPilImage, module_drawer=module_drawer)

    # Resize the QR code image
    qr_image = qr_image.resize((qr_size, qr_size))

    # Open the logo image
    logo_image = Image.open(logo_path)

    # Apply the user-defined color to the QR code pixels
    for x in range(qr_image.size[0]):
        for y in range(qr_image.size[1]):
            r, g, b = qr_image.getpixel((x, y))
            if r == 0 and g == 0 and b == 0:  # Check if pixel is black
                qr_image.putpixel((x, y), color_rgb)  # Set pixel color to user-defined color

    # Calculate the position to place the logo at the center
    logo_size = 62
    logo_position = ((qr_size - logo_size) // 2, (qr_size - logo_size) // 2)
    logo_image = logo_image.resize((logo_size, logo_size))

    # Paste the logo on the QR code image
    qr_image.paste(logo_image, logo_position)

    # Save the image file
    qr_image.save(filename)
    print("Permanent QR code generated and saved.")
    
# Function to generate and delete temporary QR code
def generate_and_delete_qr_code(data, expiration_time, filename, module_drawer=None):
    # Convert fill_color to RGB format
    fill_color = input("Enter the fill color (in hex format, e.g., #FF0000) or color name: ")

    try:
        # Try to interpret the fill color as a hex color code
        color_rgb = tuple(int(fill_color[i:i + 2], 16) for i in (1, 3, 5))
    except ValueError:
        try:
            # Try to interpret the fill color as a color name
            color_rgb = webcolors.name_to_rgb(fill_color)
        except ValueError:
            print("Invalid color input!")
            return

    # Generate the QR code
    qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_H, box_size=10, border=4)
    qr.add_data(data)
    qr.make(fit=True)

    # Generate an image from the QR code with the specified module_drawer
    qr_image = qr.make_image(fill_color=fill_color, back_color="white", image_factory=StyledPilImage, module_drawer=module_drawer)

    # Resize the QR code image
    qr_image = qr_image.resize((300, 300))

    # Apply the user-defined color to the QR code pixels
    for x in range(qr_image.size[0]):
        for y in range(qr_image.size[1]):
            r, g, b = qr_image.getpixel((x, y))
            if r == 0 and g == 0 and b == 0:  # Check if pixel is black
                qr_image.putpixel((x, y), color_rgb)  # Set pixel color to user-defined color

    # Save the image file
    qr_image.save(filename)
    print("Temporary QR code generated and saved.")

    # Calculate deletion time
    deletion_time = datetime.now() + timedelta(seconds=expiration_time)
    print(f"Temporary QR code will be deleted on: {deletion_time}")

    # Wait for the expiration time
    time.sleep(expiration_time)

    # Delete the QR code file
    os.remove(filename)
    print("Temporary QR code deleted.")

# Function to generate QR code and save it as an image file with a logo
def generate_qr_code(data, filename, qr_size, module_drawer=None):
    # Convert fill_color to RGB format
    fill_color = input("Enter the fill color (in hex format, e.g., #FF0000) or color name: ")

    try:
        # Try to interpret the fill color as a hex color code
        color_rgb = tuple(int(fill_color[i:i + 2], 16) for i in (1, 3, 5))
    except ValueError:
        try:
            # Try to interpret the fill color as a color name
            color_rgb = webcolors.name_to_rgb(fill_color)
        except ValueError:
            print("Invalid color input!")
            return

    # Generate the QR code
    qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_H, box_size=10, border=4)
    qr.add_data(data)
    qr.make(fit=True)

    # Generate an image from the QR code with the specified module_drawer
    qr_image = qr.make_image(fill_color=fill_color, back_color="white", image_factory=StyledPilImage, module_drawer=module_drawer)

    # Resize the QR code image
    qr_image = qr_image.resize((qr_size, qr_size))

    # Apply the user-defined color to the QR code pixels
    for x in range(qr_image.size[0]):
        for y in range(qr_image.size[1]):
            r, g, b = qr_image.getpixel((x, y))
            if r == 0 and g == 0 and b == 0:  # Check if pixel is black
                qr_image.putpixel((x, y), color_rgb)  # Set pixel color to user-defined color

    # Save the image file
    qr_image.save(filename)
    print("Permanent QR code generated and saved.")
    
# Function to validate a 10-digit mobile number
def validate_mobile_number(number):
    if number.isdigit() and len(number) == 10:
        return True
    return False
        
# 6 Fuctions for using our services generate a parament QR code without logo
def option_1p():
    # Get multi-line text input from the user to generate QR code
    print("Enter the text to convert to a QR code. Press Enter on a blank line to finish.")
    text_lines = []
    while True:
        line = input()
        if line:
            text_lines.append(line)
        else:
            break

    text = "\n".join(text_lines)

    qr_size = 300  # Adjust the QR code size as desired
    filename = input("Enter the filename for the QR code image: ")

    option = int(input("Select the Body pattern of QR code:\n1. Normal QR code\n2. Gapped Square QR code\n3. Rounded QR code\n4. Circle QR code\n5. Vertical Bars QR code\n6. Horizontal Bars QR code\nEnter option: "))

    if option == 1:
        generate_qr_code(text, filename, qr_size)
    elif option == 2:
        generate_qr_code(text, filename, qr_size, module_drawer=GappedSquareModuleDrawer())
    elif option == 3:
        generate_qr_code(text, filename, qr_size, module_drawer=RoundedModuleDrawer())
    elif option == 4:
        generate_qr_code(text, filename, qr_size, module_drawer=CircleModuleDrawer())
    elif option == 5:
        generate_qr_code(text, filename, qr_size, module_drawer=VerticalBarsDrawer())
    elif option == 6:
        generate_qr_code(text, filename, qr_size, module_drawer=HorizontalBarsDrawer())

    print("QR code generated successfully!")

def option_2p():
    # Get URL input from the user to convert to a QR code
    url = input("Enter the URL to convert to a QR code: ")

    qr_size = 300  # Adjust the QR code size as desired
    filename = input("Enter the filename for the QR code image: ")

    option = int(input("Select the Body pattern of QR code:\n1. Normal QR code\n2. Gapped Square QR code\n3. Rounded QR code\n4. Circle QR code\n5. Vertical Bars QR code\n6. Horizontal Bars QR code\nEnter option: "))

    if option == 1:
        generate_qr_code(url, filename, qr_size)
    elif option == 2:
        generate_qr_code(url, filename, qr_size, module_drawer=GappedSquareModuleDrawer())
    elif option == 3:
        generate_qr_code(url, filename, qr_size, module_drawer=RoundedModuleDrawer())
    elif option == 4:
        generate_qr_code(url, filename, qr_size, module_drawer=CircleModuleDrawer())
    elif option == 5:
        generate_qr_code(url, filename, qr_size, module_drawer=VerticalBarsDrawer())
    elif option == 6:
        generate_qr_code(url, filename, qr_size, module_drawer=HorizontalBarsDrawer())

    print("QR code generated successfully!")

def option_3p():
    # Get email input from the user
    email = input("Enter the email ID: ")
    subject = input("Enter the subject of the email: ")

    print("Enter the message of the email. Press Enter on a blank line to finish.")
    message_lines = []
    while True:
        line = input()
        if line:
            message_lines.append(line)
        else:
            break

    message = "\n".join(message_lines)

    # Generate the email URL
    email_url = f"mailto:{email}?subject={subject}&body={message}"

    qr_size = 300  # Adjust the QR code size as desired
    filename = input("Enter the filename for the QR code image: ")

    option = int(input("Select the Body pattern of QR code:\n1. Normal QR code\n2. Gapped Square QR code\n3. Rounded QR code\n4. Circle QR code\n5. Vertical Bars QR code\n6. Horizontal Bars QR code\nEnter option: "))

    if option == 1:
        generate_qr_code(email_url, filename, qr_size)
    elif option == 2:
        generate_qr_code(email_url, filename, qr_size, module_drawer=GappedSquareModuleDrawer())
    elif option == 3:
        generate_qr_code(email_url, filename, qr_size, module_drawer=RoundedModuleDrawer())
    elif option == 4:
        generate_qr_code(email_url, filename, qr_size, module_drawer=CircleModuleDrawer())
    elif option == 5:
        generate_qr_code(email_url, filename, qr_size, module_drawer=VerticalBarsDrawer())
    elif option == 6:
        generate_qr_code(email_url, filename, qr_size, module_drawer=HorizontalBarsDrawer())

    print("QR code generated successfully!")

def option_4p():
    # Get phone number input from the user
    phone_number = input("Enter the phone number: ")
    print("Enter the message of the email. Press Enter on a blank line to finish.")
    message_lines = []
    while True:
        line = input()
        if line:
            message_lines.append(line)
        else:
            break

    message = "\n".join(message_lines)

    # Generate the SMS URL without the body parameter
    sms_url = f"smsto:{phone_number}?body={message}"

    qr_size = 300  # Adjust the QR code size as desired
    filename = input("Enter the filename for the QR code image: ")

    option = int(input("Select the Body pattern of QR code:\n1. Normal QR code\n2. Gapped Square QR code\n3. Rounded QR code\n4. Circle QR code\n5. Vertical Bars QR code\n6. Horizontal Bars QR code\nEnter option: "))

    if option == 1:
        generate_qr_code(sms_url, filename, qr_size)
    elif option == 2:
        generate_qr_code(sms_url, filename, qr_size, module_drawer=GappedSquareModuleDrawer())
    elif option == 3:
        generate_qr_code(sms_url, filename, qr_size, module_drawer=RoundedModuleDrawer())
    elif option == 4:
        generate_qr_code(sms_url, filename, qr_size, module_drawer=CircleModuleDrawer())
    elif option == 5:
        generate_qr_code(sms_url, filename, qr_size, module_drawer=VerticalBarsDrawer())
    elif option == 6:
        generate_qr_code(sms_url, filename, qr_size, module_drawer=HorizontalBarsDrawer())

    print("QR code generated successfully!")

# Option 5: Add contact information
def option_5p():
    # Get contact information from the user
    name = input("Enter the name: ")
    email = input("Enter the email: ")
    phone = input("Enter the phone number: ")
    company = input("Enter the company name: ")
    address = input("Enter the address: ")
    city = input("Enter the city name: ")
    state = input("Enter the state name: ")
    country = input("Enter the country name: ")
    website = input("Enter the website link: ")

    # Generate the contact string in vCard format
    contact_data = f"BEGIN:VCARD\nVERSION:3.0\nN:{name}\nEMAIL:{email}\nTEL:{phone}\nORG:{company}\nADR;TYPE=WORK,PREF:;;{address};{city};{state};{country}\nURL:{website}\nEND:VCARD"

    qr_size = 300  # Adjust the QR code size as desired
    filename = input("Enter the filename for the QR code image: ")

    option = int(input("Select the Body pattern of QR code:\n1. Normal QR code\n2. Gapped Square QR code\n3. Rounded QR code\n4. Circle QR code\n5. Vertical Bars QR code\n6. Horizontal Bars QR code\nEnter option: "))

    if option == 1:
        generate_qr_code(contact_data, filename, qr_size)
    elif option == 2:
        generate_qr_code(contact_data, filename, qr_size, module_drawer=GappedSquareModuleDrawer())
    elif option == 3:
        generate_qr_code(contact_data, filename, qr_size, module_drawer=RoundedModuleDrawer())
    elif option == 4:
        generate_qr_code(contact_data, filename, qr_size, module_drawer=CircleModuleDrawer())
    elif option == 5:
        generate_qr_code(contact_data, filename, qr_size, module_drawer=VerticalBarsDrawer())
    elif option == 6:
        generate_qr_code(contact_data, filename, qr_size, module_drawer=HorizontalBarsDrawer())

    print("QR code generated successfully!")
    
def option_6p():
    # Get WiFi details from the user
    ssid = input("Enter the SSID (WiFi network name): ")
    password = input("Enter the WiFi password: ")
    encryption_type = input("Enter the encryption type (e.g., WPA(None)/WPA2): ")

    # Generate the WiFi configuration string in QR code format
    wifi_data = f"WIFI:T:{encryption_type};S:{ssid};P:{password};;"

    qr_size = 300  # Adjust the QR code size as desired
    filename = input("Enter the filename for the QR code image: ")

    option = int(input("Select the Body pattern of QR code:\n1. Normal QR code\n2. Gapped Square QR code\n3. Rounded QR code\n4. Circle QR code\n5. Vertical Bars QR code\n6. Horizontal Bars QR code\nEnter option: "))

    if option == 1:
        generate_qr_code(wifi_data, filename, qr_size)
    elif option == 2:
        generate_qr_code(wifi_data, filename, qr_size, module_drawer=GappedSquareModuleDrawer())
    elif option == 3:
        generate_qr_code(wifi_data, filename, qr_size, module_drawer=RoundedModuleDrawer())
    elif option == 4:
        generate_qr_code(wifi_data, filename, qr_size, module_drawer=CircleModuleDrawer())
    elif option == 5:
        generate_qr_code(wifi_data, filename, qr_size, module_drawer=VerticalBarsDrawer())
    elif option == 6:
        generate_qr_code(wifi_data, filename, qr_size, module_drawer=HorizontalBarsDrawer())

    print("QR code generated successfully!")
    
# 6 Fuctions for using our services generate a parament QR code with logo
def option_1pl():
    # Get multi-line text input from the user to generate QR code
    print("Enter the text to convert to a QR code. Press Enter on a blank line to finish.")
    text_lines = []
    while True:
        line = input()
        if line:
            text_lines.append(line)
        else:
            break

    text = "\n".join(text_lines)

    qr_size = 300  # Adjust the QR code size as desired
    logo_path = input("Enter the path to the logo image file: ")
    filename = input("Enter the filename for the QR code image: ")

    option = int(input("Select the Body pattern of QR code:\n1. Normal QR code\n2. Gapped Square QR code\n3. Rounded QR code\n4. Circle QR code\n5. Vertical Bars QR code\n6. Horizontal Bars QR code\nEnter option: "))

    if option == 1:
        generate_qr_code_with_logo(text, filename, qr_size, logo_path)
    elif option == 2:
        generate_qr_code_with_logo(text, filename, qr_size, logo_path, module_drawer=GappedSquareModuleDrawer())
    elif option == 3:
        generate_qr_code_with_logo(text, filename, qr_size, logo_path, module_drawer=RoundedModuleDrawer())
    elif option == 4:
        generate_qr_code_with_logo(text, filename, qr_size, logo_path, module_drawer=CircleModuleDrawer())
    elif option == 5:
        generate_qr_code_with_logo(text, filename, qr_size, logo_path, module_drawer=VerticalBarsDrawer())
    elif option == 6:
        generate_qr_code_with_logo(text, filename, qr_size, logo_path, module_drawer=HorizontalBarsDrawer())

    print("QR code generated successfully!")

def option_2pl():
    # Get URL input from the user to convert to a QR code
    url = input("Enter the URL to convert to a QR code: ")

    qr_size = 300  # Adjust the QR code size as desired
    logo_path = input("Enter the path to the logo image file: ")
    filename = input("Enter the filename for the QR code image: ")

    option = int(input("Select the Body pattern of QR code:\n1. Normal QR code\n2. Gapped Square QR code\n3. Rounded QR code\n4. Circle QR code\n5. Vertical Bars QR code\n6. Horizontal Bars QR code\nEnter option: "))

    if option == 1:
        generate_qr_code_with_logo(url, filename, qr_size, logo_path)
    elif option == 2:
        generate_qr_code_with_logo(url, filename, qr_size, logo_path, module_drawer=GappedSquareModuleDrawer())
    elif option == 3:
        generate_qr_code_with_logo(url, filename, qr_size, logo_path, module_drawer=RoundedModuleDrawer())
    elif option == 4:
        generate_qr_code_with_logo(url, filename, qr_size, logo_path, module_drawer=CircleModuleDrawer())
    elif option == 5:
        generate_qr_code_with_logo(url, filename, qr_size, logo_path, module_drawer=VerticalBarsDrawer())
    elif option == 6:
        generate_qr_code_with_logo(url, filename, qr_size, logo_path, module_drawer=HorizontalBarsDrawer())

    print("QR code generated successfully!")

def option_3pl():
    # Get email input from the user
    email = input("Enter the email ID: ")
    subject = input("Enter the subject of the email: ")

    print("Enter the message of the email. Press Enter on a blank line to finish.")
    message_lines = []
    while True:
        line = input()
        if line:
            message_lines.append(line)
        else:
            break

    message = "\n".join(message_lines)

    # Generate the email URL
    email_url = f"mailto:{email}?subject={subject}&body={message}"

    qr_size = 300  # Adjust the QR code size as desired
    logo_path = input("Enter the path to the logo image file: ")
    filename = input("Enter the filename for the QR code image: ")

    option = int(input("Select the Body pattern of QR code:\n1. Normal QR code\n2. Gapped Square QR code\n3. Rounded QR code\n4. Circle QR code\n5. Vertical Bars QR code\n6. Horizontal Bars QR code\nEnter option: "))

    if option == 1:
        generate_qr_code_with_logo(email_url, filename, qr_size, logo_path)
    elif option == 2:
        generate_qr_code_with_logo(email_url, filename, qr_size, logo_path, module_drawer=GappedSquareModuleDrawer())
    elif option == 3:
        generate_qr_code_with_logo(email_url, filename, qr_size, logo_path, module_drawer=RoundedModuleDrawer())
    elif option == 4:
        generate_qr_code_with_logo(email_url, filename, qr_size, logo_path, module_drawer=CircleModuleDrawer())
    elif option == 5:
        generate_qr_code_with_logo(email_url, filename, qr_size, logo_path, module_drawer=VerticalBarsDrawer())
    elif option == 6:
        generate_qr_code_with_logo(email_url, filename, qr_size, logo_path, module_drawer=HorizontalBarsDrawer())

    print("QR code generated successfully!")

def option_4pl():
    # Get phone number input from the user
    phone_number = input("Enter the phone number: ")
    print("Enter the message of the email. Press Enter on a blank line to finish.")
    message_lines = []
    while True:
        line = input()
        if line:
            message_lines.append(line)
        else:
            break

    message = "\n".join(message_lines)

    # Generate the SMS URL without the body parameter
    sms_url = f"smsto:{phone_number}?body={message}"

    qr_size = 300  # Adjust the QR code size as desired
    logo_path = input("Enter the path to the logo image file: ")
    filename = input("Enter the filename for the QR code image: ")

    option = int(input("Select the Body pattern of QR code:\n1. Normal QR code\n2. Gapped Square QR code\n3. Rounded QR code\n4. Circle QR code\n5. Vertical Bars QR code\n6. Horizontal Bars QR code\nEnter option: "))

    if option == 1:
        generate_qr_code_with_logo(sms_url, filename, qr_size, logo_path)
    elif option == 2:
        generate_qr_code_with_logo(sms_url, filename, qr_size, logo_path, module_drawer=GappedSquareModuleDrawer())
    elif option == 3:
        generate_qr_code_with_logo(sms_url, filename, qr_size, logo_path, module_drawer=RoundedModuleDrawer())
    elif option == 4:
        generate_qr_code_with_logo(sms_url, filename, qr_size, logo_path, module_drawer=CircleModuleDrawer())
    elif option == 5:
        generate_qr_code_with_logo(sms_url, filename, qr_size, logo_path, module_drawer=VerticalBarsDrawer())
    elif option == 6:
        generate_qr_code_with_logo(sms_url, filename, qr_size, logo_path, module_drawer=HorizontalBarsDrawer())

    print("QR code generated successfully!")

# Option 5: Add contact information
def option_5pl():
    # Get contact information from the user
    name = input("Enter the name: ")
    email = input("Enter the email: ")
    phone = input("Enter the phone number: ")
    company = input("Enter the company name: ")
    address = input("Enter the address: ")
    city = input("Enter the city name: ")
    state = input("Enter the state name: ")
    country = input("Enter the country name: ")
    website = input("Enter the website link: ")

    # Generate the contact string in vCard format
    contact_data = f"BEGIN:VCARD\nVERSION:3.0\nN:{name}\nEMAIL:{email}\nTEL:{phone}\nORG:{company}\nADR;TYPE=WORK,PREF:;;{address};{city};{state};{country}\nURL:{website}\nEND:VCARD"

    qr_size = 300  # Adjust the QR code size as desired
    logo_path = input("Enter the path to the logo image file: ")
    filename = input("Enter the filename for the QR code image: ")

    option = int(input("Select the Body pattern of QR code:\n1. Normal QR code\n2. Gapped Square QR code\n3. Rounded QR code\n4. Circle QR code\n5. Vertical Bars QR code\n6. Horizontal Bars QR code\nEnter option: "))

    if option == 1:
        generate_qr_code_with_logo(contact_data, filename, qr_size, logo_path)
    elif option == 2:
        generate_qr_code_with_logo(contact_data, filename, qr_size, logo_path, module_drawer=GappedSquareModuleDrawer())
    elif option == 3:
        generate_qr_code_with_logo(contact_data, filename, qr_size, logo_path, module_drawer=RoundedModuleDrawer())
    elif option == 4:
        generate_qr_code_with_logo(contact_data, filename, qr_size, logo_path, module_drawer=CircleModuleDrawer())
    elif option == 5:
        generate_qr_code_with_logo(contact_data, filename, qr_size, logo_path, module_drawer=VerticalBarsDrawer())
    elif option == 6:
        generate_qr_code_with_logo(contact_data, filename, qr_size, logo_path, module_drawer=HorizontalBarsDrawer())

    print("QR code generated successfully!")
    
def option_6pl():
    # Get WiFi details from the user
    ssid = input("Enter the SSID (WiFi network name): ")
    password = input("Enter the WiFi password: ")
    encryption_type = input("Enter the encryption type (e.g., WPA(None)/WPA2): ")

    # Generate the WiFi configuration string in QR code format
    wifi_data = f"WIFI:T:{encryption_type};S:{ssid};P:{password};;"

    qr_size = 300  # Adjust the QR code size as desired
    logo_path = input("Enter the path to the logo image file: ")
    filename = input("Enter the filename for the QR code image: ")

    option = int(input("Select the Body pattern of QR code:\n1. Normal QR code\n2. Gapped Square QR code\n3. Rounded QR code\n4. Circle QR code\n5. Vertical Bars QR code\n6. Horizontal Bars QR code\nEnter option: "))

    if option == 1:
        generate_qr_code_with_logo(wifi_data, filename, qr_size, logo_path)
    elif option == 2:
        generate_qr_code_with_logo(wifi_data, filename, qr_size, logo_path, module_drawer=GappedSquareModuleDrawer())
    elif option == 3:
        generate_qr_code_with_logo(wifi_data, filename, qr_size, logo_path, module_drawer=RoundedModuleDrawer())
    elif option == 4:
        generate_qr_code_with_logo(wifi_data, filename, qr_size, logo_path, module_drawer=CircleModuleDrawer())
    elif option == 5:
        generate_qr_code_with_logo(wifi_data, filename, qr_size, logo_path, module_drawer=VerticalBarsDrawer())
    elif option == 6:
        generate_qr_code_with_logo(wifi_data, filename, qr_size, logo_path, module_drawer=HorizontalBarsDrawer())

    print("QR code generated successfully!")
    
# 6 Fuctions for using our services generate a temporary QR code with logo
def option_1tl():
    # Get multi-line text input from the user to generate QR code
    print("Enter the text to convert to a QR code. Press Enter on a blank line to finish.")
    text_lines = []
    while True:
        line = input()
        if line:
            text_lines.append(line)
        else:
            break

    text = "\n".join(text_lines)

    qr_size = 300  # Adjust the QR code size as desired
    expiration_time = int(input("Enter the expiration time (in seconds): "))
    logo_path = input("Enter the path to the logo image file: ")
    filename = input("Enter the filename for the QR code image: ")

    option = int(input("Select the Body pattern of QR code:\n1. Normal QR code\n2. Gapped Square QR code\n3. Rounded QR code\n4. Circle QR code\n5. Vertical Bars QR code\n6. Horizontal Bars QR code\nEnter option: "))

    if option == 1:
        generate_and_delete_qr_code_with_logo(text, expiration_time, logo_path, filename)
    elif option == 2:
        generate_and_delete_qr_code_with_logo(text, expiration_time, logo_path, filename, module_drawer=GappedSquareModuleDrawer())
    elif option == 3:
        generate_and_delete_qr_code_with_logo(text, expiration_time, logo_path, filename, module_drawer=RoundedModuleDrawer())
    elif option == 4:
        generate_and_delete_qr_code_with_logo(text, expiration_time, logo_path, filename, module_drawer=CircleModuleDrawer())
    elif option == 5:
        generate_and_delete_qr_code_with_logo(text, expiration_time, logo_path, filename, module_drawer=VerticalBarsDrawer())
    elif option == 6:
        generate_and_delete_qr_code_with_logo(text, expiration_time, logo_path, filename, module_drawer=HorizontalBarsDrawer())

    print("QR code generated successfully!")

def option_2tl():
    # Get URL input from the user to convert to a QR code
    url = input("Enter the URL to convert to a QR code: ")

    qr_size = 300  # Adjust the QR code size as desired
    expiration_time = int(input("Enter the expiration time (in seconds): "))
    logo_path = input("Enter the path to the logo image file: ")
    filename = input("Enter the filename for the QR code image: ")

    option = int(input("Select the Body pattern of QR code:\n1. Normal QR code\n2. Gapped Square QR code\n3. Rounded QR code\n4. Circle QR code\n5. Vertical Bars QR code\n6. Horizontal Bars QR code\nEnter option: "))

    if option == 1:
        generate_and_delete_qr_code_with_logo(url, expiration_time, logo_path, filename)
    elif option == 2:
        generate_and_delete_qr_code_with_logo(url, expiration_time, logo_path, filename, module_drawer=GappedSquareModuleDrawer())
    elif option == 3:
        generate_and_delete_qr_code_with_logo(url, expiration_time, logo_path, filename, module_drawer=RoundedModuleDrawer())
    elif option == 4:
        generate_and_delete_qr_code_with_logo(url, expiration_time, logo_path, filename, module_drawer=CircleModuleDrawer())
    elif option == 5:
        generate_and_delete_qr_code_with_logo(url, expiration_time, logo_path, filename, module_drawer=VerticalBarsDrawer())
    elif option == 6:
        generate_and_delete_qr_code_with_logo(url, expiration_time, logo_path, filename, module_drawer=HorizontalBarsDrawer())

    print("QR code generated successfully!")

def option_3tl():
    # Get email input from the user
    email = input("Enter the email ID: ")
    subject = input("Enter the subject of the email: ")

    print("Enter the message of the email. Press Enter on a blank line to finish.")
    message_lines = []
    while True:
        line = input()
        if line:
            message_lines.append(line)
        else:
            break

    message = "\n".join(message_lines)

    # Generate the email URL
    email_url = f"mailto:{email}?subject={subject}&body={message}"

    qr_size = 300  # Adjust the QR code size as desired
    expiration_time = int(input("Enter the expiration time (in seconds): "))
    logo_path = input("Enter the path to the logo image file: ")
    filename = input("Enter the filename for the QR code image: ")

    option = int(input("Select the Body pattern of QR code:\n1. Normal QR code\n2. Gapped Square QR code\n3. Rounded QR code\n4. Circle QR code\n5. Vertical Bars QR code\n6. Horizontal Bars QR code\nEnter option: "))

    if option == 1:
        generate_and_delete_qr_code_with_logo(email_url, expiration_time, logo_path, filename)
    elif option == 2:
        generate_and_delete_qr_code_with_logo(email_url, expiration_time, logo_path, filename, module_drawer=GappedSquareModuleDrawer())
    elif option == 3:
        generate_and_delete_qr_code_with_logo(email_url, expiration_time, logo_path, filename, module_drawer=RoundedModuleDrawer())
    elif option == 4:
        generate_and_delete_qr_code_with_logo(email_url, expiration_time, logo_path, filename, module_drawer=CircleModuleDrawer())
    elif option == 5:
        generate_and_delete_qr_code_with_logo(email_url, expiration_time, logo_path, filename, module_drawer=VerticalBarsDrawer())
    elif option == 6:
        generate_and_delete_qr_code_with_logo(email_url, expiration_time, logo_path, filename, module_drawer=HorizontalBarsDrawer())

    print("QR code generated successfully!")

def option_4tl():
    # Get phone number input from the user
    phone_number = input("Enter the phone number: ")
    print("Enter the message of the email. Press Enter on a blank line to finish.")
    message_lines = []
    while True:
        line = input()
        if line:
            message_lines.append(line)
        else:
            break

    message = "\n".join(message_lines)

    # Generate the SMS URL without the body parameter
    sms_url = f"smsto:{phone_number}?body={message}"

    qr_size = 300  # Adjust the QR code size as desired
    expiration_time = int(input("Enter the expiration time (in seconds): "))
    logo_path = input("Enter the path to the logo image file: ")
    filename = input("Enter the filename for the QR code image: ")

    option = int(input("Select the Body pattern of QR code:\n1. Normal QR code\n2. Gapped Square QR code\n3. Rounded QR code\n4. Circle QR code\n5. Vertical Bars QR code\n6. Horizontal Bars QR code\nEnter option: "))

    if option == 1:
        generate_and_delete_qr_code_with_logo(sms_url, expiration_time, logo_path, filename)
    elif option == 2:
        generate_and_delete_qr_code_with_logo(sms_url, expiration_time, logo_path, filename, module_drawer=GappedSquareModuleDrawer())
    elif option == 3:
        generate_and_delete_qr_code_with_logo(sms_url, expiration_time, logo_path, filename, module_drawer=RoundedModuleDrawer())
    elif option == 4:
        generate_and_delete_qr_code_with_logo(sms_url, expiration_time, logo_path, filename, module_drawer=CircleModuleDrawer())
    elif option == 5:
        generate_and_delete_qr_code_with_logo(sms_url, expiration_time, logo_path, filename, module_drawer=VerticalBarsDrawer())
    elif option == 6:
        generate_and_delete_qr_code_with_logo(sms_url, expiration_time, logo_path, filename, module_drawer=HorizontalBarsDrawer())

    print("QR code generated successfully!")

# Option 5: Add contact information
def option_5tl():
    # Get contact information from the user
    name = input("Enter the name: ")
    email = input("Enter the email: ")
    phone = input("Enter the phone number: ")
    company = input("Enter the company name: ")
    address = input("Enter the address: ")
    city = input("Enter the city name: ")
    state = input("Enter the state name: ")
    country = input("Enter the country name: ")
    website = input("Enter the website link: ")

    # Generate the contact string in vCard format
    contact_data = f"BEGIN:VCARD\nVERSION:3.0\nN:{name}\nEMAIL:{email}\nTEL:{phone}\nORG:{company}\nADR;TYPE=WORK,PREF:;;{address};{city};{state};{country}\nURL:{website}\nEND:VCARD"

    qr_size = 300  # Adjust the QR code size as desired
    expiration_time = int(input("Enter the expiration time (in seconds): "))
    logo_path = input("Enter the path to the logo image file: ")
    filename = input("Enter the filename for the QR code image: ")

    option = int(input("Select the Body pattern of QR code:\n1. Normal QR code\n2. Gapped Square QR code\n3. Rounded QR code\n4. Circle QR code\n5. Vertical Bars QR code\n6. Horizontal Bars QR code\nEnter option: "))

    if option == 1:
        generate_and_delete_qr_code_with_logo(contact_data, expiration_time, logo_path, filename)
    elif option == 2:
        generate_and_delete_qr_code_with_logo(contact_data, expiration_time, logo_path, filename, module_drawer=GappedSquareModuleDrawer())
    elif option == 3:
        generate_and_delete_qr_code_with_logo(contact_data, expiration_time, logo_path, filename, module_drawer=RoundedModuleDrawer())
    elif option == 4:
        generate_and_delete_qr_code_with_logo(contact_data, expiration_time, logo_path, filename, module_drawer=CircleModuleDrawer())
    elif option == 5:
        generate_and_delete_qr_code_with_logo(contact_data, expiration_time, logo_path, filename, module_drawer=VerticalBarsDrawer())
    elif option == 6:
        generate_and_delete_qr_code_with_logo(contact_data, expiration_time, logo_path, filename, module_drawer=HorizontalBarsDrawer())

    print("QR code generated successfully!")
    
def option_6tl():
    # Get WiFi details from the user
    ssid = input("Enter the SSID (WiFi network name): ")
    password = input("Enter the WiFi password: ")
    encryption_type = input("Enter the encryption type (e.g., WPA(None)/WPA2): ")

    # Generate the WiFi configuration string in QR code format
    wifi_data = f"WIFI:T:{encryption_type};S:{ssid};P:{password};;"

    qr_size = 300  # Adjust the QR code size as desired
    expiration_time = int(input("Enter the expiration time (in seconds): "))
    logo_path = input("Enter the path to the logo image file: ")
    filename = input("Enter the filename for the QR code image: ")

    option = int(input("Select the Body pattern of QR code:\n1. Normal QR code\n2. Gapped Square QR code\n3. Rounded QR code\n4. Circle QR code\n5. Vertical Bars QR code\n6. Horizontal Bars QR code\nEnter option: "))

    if option == 1:
        generate_and_delete_qr_code_with_logo(wifi_data, expiration_time, logo_path, filename)
    elif option == 2:
        generate_and_delete_qr_code_with_logo(wifi_data, expiration_time, logo_path, filename, module_drawer=GappedSquareModuleDrawer())
    elif option == 3:
        generate_and_delete_qr_code_with_logo(wifi_data, expiration_time, logo_path, filename, module_drawer=RoundedModuleDrawer())
    elif option == 4:
        generate_and_delete_qr_code_with_logo(wifi_data, expiration_time, logo_path, filename, module_drawer=CircleModuleDrawer())
    elif option == 5:
        generate_and_delete_qr_code_with_logo(wifi_data, expiration_time, logo_path, filename, module_drawer=VerticalBarsDrawer())
    elif option == 6:
        generate_and_delete_qr_code_with_logo(wifi_data, expiration_time, logo_path, filename, module_drawer=HorizontalBarsDrawer())

    print("QR code generated successfully!")
        
# 6 Fuctions for using our services generate a temporary QR code without logo
def option_1t():
    # Get multi-line text input from the user to generate QR code
    print("Enter the text to convert to a QR code. Press Enter on a blank line to finish.")
    text_lines = []
    while True:
        line = input()
        if line:
            text_lines.append(line)
        else:
            break

    text = "\n".join(text_lines)

    qr_size = 300  # Adjust the QR code size as desired
    expiration_time = int(input("Enter the expiration time (in seconds): "))
    filename = input("Enter the filename for the QR code image: ")

    option = int(input("Select the Body pattern of QR code:\n1. Normal QR code\n2. Gapped Square QR code\n3. Rounded QR code\n4. Circle QR code\n5. Vertical Bars QR code\n6. Horizontal Bars QR code\nEnter option: "))

    if option == 1:
        generate_and_delete_qr_code(text, expiration_time, filename)
    elif option == 2:
        generate_and_delete_qr_code(text, expiration_time, filename, module_drawer=GappedSquareModuleDrawer())
    elif option == 3:
        generate_and_delete_qr_code(text, expiration_time, filename, module_drawer=RoundedModuleDrawer())
    elif option == 4:
        generate_and_delete_qr_code(text, expiration_time, filename, module_drawer=CircleModuleDrawer())
    elif option == 5:
        generate_and_delete_qr_code(text, expiration_time, filename, module_drawer=VerticalBarsDrawer())
    elif option == 6:
        generate_and_delete_qr_code(text, expiration_time, filename, module_drawer=HorizontalBarsDrawer())

    print("QR code generated successfully!")

def option_2t():
    # Get URL input from the user to convert to a QR code
    url = input("Enter the URL to convert to a QR code: ")

    qr_size = 300  # Adjust the QR code size as desired
    expiration_time = int(input("Enter the expiration time (in seconds): "))
    filename = input("Enter the filename for the QR code image: ")

    option = int(input("Select the Body pattern of QR code:\n1. Normal QR code\n2. Gapped Square QR code\n3. Rounded QR code\n4. Circle QR code\n5. Vertical Bars QR code\n6. Horizontal Bars QR code\nEnter option: "))

    if option == 1:
        generate_and_delete_qr_code(url, expiration_time, filename)
    elif option == 2:
        generate_and_delete_qr_code(url, expiration_time, filename, module_drawer=GappedSquareModuleDrawer())
    elif option == 3:
        generate_and_delete_qr_code(url, expiration_time, filename, module_drawer=RoundedModuleDrawer())
    elif option == 4:
        generate_and_delete_qr_code(url, expiration_time, filename, module_drawer=CircleModuleDrawer())
    elif option == 5:
        generate_and_delete_qr_code(url, expiration_time, filename, module_drawer=VerticalBarsDrawer())
    elif option == 6:
        generate_and_delete_qr_code(url, expiration_time, filename, module_drawer=HorizontalBarsDrawer())

    print("QR code generated successfully!")

def option_3t():
    # Get email input from the user
    email = input("Enter the email ID: ")
    subject = input("Enter the subject of the email: ")

    print("Enter the message of the email. Press Enter on a blank line to finish.")
    message_lines = []
    while True:
        line = input()
        if line:
            message_lines.append(line)
        else:
            break

    message = "\n".join(message_lines)

    # Generate the email URL
    email_url = f"mailto:{email}?subject={subject}&body={message}"

    qr_size = 300  # Adjust the QR code size as desired
    expiration_time = int(input("Enter the expiration time (in seconds): "))
    filename = input("Enter the filename for the QR code image: ")

    option = int(input("Select the Body pattern of QR code:\n1. Normal QR code\n2. Gapped Square QR code\n3. Rounded QR code\n4. Circle QR code\n5. Vertical Bars QR code\n6. Horizontal Bars QR code\nEnter option: "))

    if option == 1:
        generate_and_delete_qr_code(email_url, expiration_time, filename)
    elif option == 2:
        generate_and_delete_qr_code(email_url, expiration_time, filename, module_drawer=GappedSquareModuleDrawer())
    elif option == 3:
        generate_and_delete_qr_code(email_url, expiration_time, filename, module_drawer=RoundedModuleDrawer())
    elif option == 4:
        generate_and_delete_qr_code(email_url, expiration_time, filename, module_drawer=CircleModuleDrawer())
    elif option == 5:
        generate_and_delete_qr_code(email_url, expiration_time, filename, module_drawer=VerticalBarsDrawer())
    elif option == 6:
        generate_and_delete_qr_code(email_url, expiration_time, filename, module_drawer=HorizontalBarsDrawer())

    print("QR code generated successfully!")

def option_4t():
    # Get phone number input from the user
    phone_number = input("Enter the phone number: ")
    print("Enter the message of the email. Press Enter on a blank line to finish.")
    message_lines = []
    while True:
        line = input()
        if line:
            message_lines.append(line)
        else:
            break

    message = "\n".join(message_lines)

    # Generate the SMS URL without the body parameter
    sms_url = f"smsto:{phone_number}?body={message}"

    qr_size = 300  # Adjust the QR code size as desired
    expiration_time = int(input("Enter the expiration time (in seconds): "))
    filename = input("Enter the filename for the QR code image: ")

    option = int(input("Select the Body pattern of QR code:\n1. Normal QR code\n2. Gapped Square QR code\n3. Rounded QR code\n4. Circle QR code\n5. Vertical Bars QR code\n6. Horizontal Bars QR code\nEnter option: "))

    if option == 1:
        generate_and_delete_qr_code(sms_url, expiration_time, filename)
    elif option == 2:
        generate_and_delete_qr_code(sms_url, expiration_time, filename, module_drawer=GappedSquareModuleDrawer())
    elif option == 3:
        generate_and_delete_qr_code(sms_url, expiration_time, filename, module_drawer=RoundedModuleDrawer())
    elif option == 4:
        generate_and_delete_qr_code(sms_url, expiration_time, filename, module_drawer=CircleModuleDrawer())
    elif option == 5:
        generate_and_delete_qr_code(sms_url, expiration_time, filename, module_drawer=VerticalBarsDrawer())
    elif option == 6:
        generate_and_delete_qr_code(sms_url, expiration_time, filename, module_drawer=HorizontalBarsDrawer())

    print("QR code generated successfully!")

# Option 5: Add contact information
def option_5t():
    # Get contact information from the user
    name = input("Enter the name: ")
    email = input("Enter the email: ")
    phone = input("Enter the phone number: ")
    company = input("Enter the company name: ")
    address = input("Enter the address: ")
    city = input("Enter the city name: ")
    state = input("Enter the state name: ")
    country = input("Enter the country name: ")
    website = input("Enter the website link: ")

    # Generate the contact string in vCard format
    contact_data = f"BEGIN:VCARD\nVERSION:3.0\nN:{name}\nEMAIL:{email}\nTEL:{phone}\nORG:{company}\nADR;TYPE=WORK,PREF:;;{address};{city};{state};{country}\nURL:{website}\nEND:VCARD"

    qr_size = 300  # Adjust the QR code size as desired
    expiration_time = int(input("Enter the expiration time (in seconds): "))
    filename = input("Enter the filename for the QR code image: ")

    option = int(input("Select the Body pattern of QR code:\n1. Normal QR code\n2. Gapped Square QR code\n3. Rounded QR code\n4. Circle QR code\n5. Vertical Bars QR code\n6. Horizontal Bars QR code\nEnter option: "))

    if option == 1:
        generate_and_delete_qr_code(contact_data, expiration_time, filename)
    elif option == 2:
        generate_and_delete_qr_code(contact_data, expiration_time, filename, module_drawer=GappedSquareModuleDrawer())
    elif option == 3:
        generate_and_delete_qr_code(contact_data, expiration_time, filename, module_drawer=RoundedModuleDrawer())
    elif option == 4:
        generate_and_delete_qr_code(contact_data, expiration_time, filename, module_drawer=CircleModuleDrawer())
    elif option == 5:
        generate_and_delete_qr_code(contact_data, expiration_time, filename, module_drawer=VerticalBarsDrawer())
    elif option == 6:
        generate_and_delete_qr_code(contact_data, expiration_time, filename, module_drawer=HorizontalBarsDrawer())

    print("QR code generated successfully!")
    
def option_6t():
    # Get WiFi details from the user
    ssid = input("Enter the SSID (WiFi network name): ")
    password = input("Enter the WiFi password: ")
    encryption_type = input("Enter the encryption type (e.g., WPA(None)/WPA2): ")

    # Generate the WiFi configuration string in QR code format
    wifi_data = f"WIFI:T:{encryption_type};S:{ssid};P:{password};;"

    qr_size = 300  # Adjust the QR code size as desired
    expiration_time = int(input("Enter the expiration time (in seconds): "))
    filename = input("Enter the filename for the QR code image: ")

    option = int(input("Select the Body pattern of QR code:\n1. Normal QR code\n2. Gapped Square QR code\n3. Rounded QR code\n4. Circle QR code\n5. Vertical Bars QR code\n6. Horizontal Bars QR code\nEnter option: "))

    if option == 1:
        generate_and_delete_qr_code(wifi_data, expiration_time, filename)
    elif option == 2:
        generate_and_delete_qr_code(wifi_data, expiration_time, filename, module_drawer=GappedSquareModuleDrawer())
    elif option == 3:
        generate_and_delete_qr_code(wifi_data, expiration_time, filename, module_drawer=RoundedModuleDrawer())
    elif option == 4:
        generate_and_delete_qr_code(wifi_data, expiration_time, filename, module_drawer=CircleModuleDrawer())
    elif option == 5:
        generate_and_delete_qr_code(wifi_data, expiration_time, filename, module_drawer=VerticalBarsDrawer())
    elif option == 6:
        generate_and_delete_qr_code(wifi_data, expiration_time, filename, module_drawer=HorizontalBarsDrawer())

    print("QR code generated successfully!")
    
# Option 2: Check Login
def check_login():
    # Get user input for login information (username and email ID)
    username_email = input("Enter username or email ID: ")
    
    # Use getpass to hide the password as it's typed
    Password = getpass.getpass("Enter the Password: ")

    # Execute a SELECT query to check for a match
    select_query = "SELECT * FROM admin_signup WHERE (User_name = %s OR Email_ID = %s) AND Password = %s"
    cursor.execute(select_query, (username_email, username_email, Password))

    # Fetch the first row from the result set
    row = cursor.fetchone()

    # Check if a match is found
    if row is not None:
        print("Login successful!")

        while True:
            # Prompt the user to select an option
            print("Select an option:")
            print("1. Get free trail")
            print("2. take a plan")
            #print("4. Delete Account")
            print("3. Sign Out")
            option = int(input("Enter your choice (1, 2, 3, or 4): "))
            
            if option == 1:
                while True:
                    # Prompt the user to select an option
                    print("Select an option:")
                    print("1. Convert text to QR code for temporary")
                    print("2. Convert URL to QR code for temporary")
                    print("3. Generate QR code for email ID for temporary")
                    print("4. Generate QR code for SMS for temporary")
                    print("5. Generate QR code for vCard for temporary")
                    print("6. Generate QR code for wi-fi for temporary")
                    print("7. Sign Out")
                    option = int(input("Enter your choice (1, 2, 3, 4, 5, 6, or 7): "))

                    if option == 1:
                        option_1t()
                    elif option == 2:
                        option_2t()
                    elif option == 3:
                        option_3t()
                    elif option == 4:
                        option_4t()
                    elif option == 5:
                        option_5t()
                    elif option == 6:
                        option_6t()
                    elif option == 7:
                        print("Signed out successfully!")
                        break
                    else:
                        print("Invalid option!")
            elif option == 2:
                while True:
                    # Prompt the user to select an option
                    print("Select an option:")
                    print("1. Generete Temporary QR code")
                    print("2. Generate Permanent QR code")
                    print("3. Exit")
                    option = int(input("Enter your choice (1, 2, or 3): "))
                    
                    if option == 1:
                        while True:
                            # Prompt the user to select an option
                            print("Select an option:")
                            print("1. Generete Temporary QR code with logo")
                            print("2. Generate Temporary QR code without logo")
                            print("3. Exit")
                            option = int(input("Enter your choice (1, 2, or 3): "))
                    
                            if option == 1:
                                while True:
                                    # Prompt the user to select an option
                                    print("Select an option:")
                                    print("1. Convert text to QR code for temporary with logo")
                                    print("2. Convert URL to QR code for temporary with logo")
                                    print("3. Generate QR code for email ID for temporary with logo")
                                    print("4. Generate QR code for SMS for temporary with logo")
                                    print("5. Generate QR code for vCard for temporary with logo")
                                    print("6. Generate QR code for wi-fi for temporary with logo")
                                    print("7. Sign Out")
                                    option = int(input("Enter your choice (1, 2, 3, 4, 5, 6, or 7): "))

                                    if option == 1:
                                        option_1tl()
                                    elif option == 2:
                                        option_2tl()
                                    elif option == 3:
                                        option_3tl()
                                    elif option == 4:
                                        option_4tl()
                                    elif option == 5:
                                        option_5tl()
                                    elif option == 6:
                                        option_6tl()
                                    elif option == 7:
                                        print("Signed out successfully!")
                                        break
                                    else:
                                        print("Invalid option!")
                            elif option == 2:
                                while True:
                                    # Prompt the user to select an option
                                    print("Select an option:")
                                    print("1. Convert text to QR code for temporary")
                                    print("2. Convert URL to QR code for temporary")
                                    print("3. Generate QR code for email ID for temporary")
                                    print("4. Generate QR code for SMS for temporary")
                                    print("5. Generate QR code for vCard for temporary")
                                    print("6. Generate QR code for wi-fi for temporary")
                                    print("7. Sign Out")
                                    option = int(input("Enter your choice (1, 2, 3, 4, 5, 6, or 7): "))

                                    if option == 1:
                                        option_1t()
                                    elif option == 2:
                                        option_2t()
                                    elif option == 3:
                                        option_3t()
                                    elif option == 4:
                                        option_4t()
                                    elif option == 5:
                                        option_5t()
                                    elif option == 6:
                                        option_6t()
                                    elif option == 7:
                                        print("Signed out successfully!")
                                        break
                                    else:
                                        print("Invalid option!")
                            elif option == 3:
                                break
                            else:
                                print("Invalid option!")
                    elif option == 2:
                        while True:
                            # Prompt the user to select an option
                            print("Select an option:")
                            print("1. Generete Permanent QR code with logo")
                            print("2. Generate Permanent QR code without logo")
                            print("3. Exit")
                            option = int(input("Enter your choice (1, 2, or 3): "))
                    
                            if option == 1:
                                while True:
                                    # Prompt the user to select an option
                                    print("Select an option:")
                                    print("1. Convert text to QR code with logo")
                                    print("2. Convert URL to QR code with logo")
                                    print("3. Generate QR code for email ID with logo")
                                    print("4. Generate QR code for SMS with logo")
                                    print("5. Generate QR code for vCard with logo")
                                    print("6. Generate QR code for wi-fi with logo")
                                    print("7. Sign Out")
                                    option = int(input("Enter your choice (1, 2, 3, 4, 5, 6, or 7): "))

                                    if option == 1:
                                        option_1pl()
                                    elif option == 2:
                                        option_2pl()
                                    elif option == 3:
                                        option_3pl()
                                    elif option == 4:
                                        option_4pl()
                                    elif option == 5:
                                        option_5pl()
                                    elif option == 6:
                                        option_6pl()
                                    elif option == 7:
                                        print("Signed out successfully!")
                                        break
                                    else:
                                        print("Invalid option!")
                            elif option == 2:
                                while True:
                                    # Prompt the user to select an option
                                    print("Select an option:")
                                    print("1. Convert text to QR code")
                                    print("2. Convert URL to QR code")
                                    print("3. Generate QR code for email ID")
                                    print("4. Generate QR code for SMS")
                                    print("5. Generate QR code for vCard")
                                    print("6. Generate QR code for wi-fi")
                                    print("7. Sign Out")
                                    option = int(input("Enter your choice (1, 2, 3, 4, 5, 6, or 7): "))

                                    if option == 1:
                                        option_1p()
                                    elif option == 2:
                                        option_2p()
                                    elif option == 3:
                                        option_3p()
                                    elif option == 4:
                                        option_4p()
                                    elif option == 5:
                                        option_5p()
                                    elif option == 6:
                                        option_6p()
                                    elif option == 7:
                                        print("Signed out successfully!")
                                        break
                                    else:
                                        print("Invalid option!")
                            elif option == 3:
                                break
                            else:
                                print("Invalid option!")
                    elif option == 3:
                        break
                    else:
                        print("Invalid option!")
                         
            elif option == 3:
                print("Signed out successfully!")
                break
            else:
                print("Invalid option!")
                
    else:
        print("Invalid Username or Password")

# Close the cursor and the database connection
cursor.close()
cnx.close()

print("Thank you for using our Services!!")
