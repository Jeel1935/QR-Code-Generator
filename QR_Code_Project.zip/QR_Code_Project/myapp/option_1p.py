import mysql.connector
import qrcode
import getpass
from PIL import Image
import webcolors
import time
import os
from datetime import datetime, timedelta
from qrcode.image.styledpil import StyledPilImage
from qrcode.image.styles.moduledrawers import (
    GappedSquareModuleDrawer,
    RoundedModuleDrawer,
    CircleModuleDrawer,
    VerticalBarsDrawer,
    HorizontalBarsDrawer,
)


# Function to generate QR code and save it as an image file with a logo
def generate_qr_code(data, filename, qr_size, module_drawer=None):
    # Convert fill_color to RGB format
    fill_color = input("Enter the fill color (in hex format, e.g., #FF0000) or color name: ")

    try:
        # Try to interpret the fill color as a hex color code
        color_rgb = tuple(int(fill_color[i:i + 2], 16) for i in (1, 3, 5))
    except ValueError:
        try:
            # Try to interpret the fill color as a color name
            color_rgb = webcolors.name_to_rgb(fill_color)
        except ValueError:
            print("Invalid color input!")
            return

    # Generate the QR code
    qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_H, box_size=10, border=4)
    qr.add_data(data)
    qr.make(fit=True)

    # Generate an image from the QR code with the specified module_drawer
    qr_image = qr.make_image(fill_color=fill_color, back_color="white", image_factory=StyledPilImage, module_drawer=module_drawer)

    # Resize the QR code image
    qr_image = qr_image.resize((qr_size, qr_size))

    # Apply the user-defined color to the QR code pixels
    for x in range(qr_image.size[0]):
        for y in range(qr_image.size[1]):
            r, g, b = qr_image.getpixel((x, y))
            if r == 0 and g == 0 and b == 0:  # Check if pixel is black
                qr_image.putpixel((x, y), color_rgb)  # Set pixel color to user-defined color

    # Save the image file
    qr_image.save(filename)
    print("Permanent QR code generated and saved.")


def option_1p():
    # Get multi-line text input from the user to generate QR code
    print("Enter the text to convert to a QR code. Press Enter on a blank line to finish.")
    text_lines = []
    while True:
        line = input()
        if line:
            text_lines.append(line)
        else:
            break

    text = "\n".join(text_lines)

    qr_size = 300  # Adjust the QR code size as desired
    filename = input("Enter the filename for the QR code image: ")

    option = int(input("Select the Body pattern of QR code:\n1. Normal QR code\n2. Gapped Square QR code\n3. Rounded QR code\n4. Circle QR code\n5. Vertical Bars QR code\n6. Horizontal Bars QR code\nEnter option: "))

    if option == 1:
        generate_qr_code(text, filename, qr_size)
    elif option == 2:
        generate_qr_code(text, filename, qr_size, module_drawer=GappedSquareModuleDrawer())
    elif option == 3:
        generate_qr_code(text, filename, qr_size, module_drawer=RoundedModuleDrawer())
    elif option == 4:
        generate_qr_code(text, filename, qr_size, module_drawer=CircleModuleDrawer())
    elif option == 5:
        generate_qr_code(text, filename, qr_size, module_drawer=VerticalBarsDrawer())
    elif option == 6:
        generate_qr_code(text, filename, qr_size, module_drawer=HorizontalBarsDrawer())

    print("QR code generated successfully!")