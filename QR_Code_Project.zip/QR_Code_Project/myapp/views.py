from django.shortcuts import render,HttpResponse,redirect
from django.contrib.auth.models import User
from django.contrib.auth import get_user_model
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages
from django.contrib.auth import update_session_auth_hash
import qrcode
from PIL import Image
from io import BytesIO
import base64

# Create your views here.
def homePage(request):
    return render(request, "index.html")

def SignUp(request):
    if request.method=='POST':
        uname=request.POST.get('username')
        email=request.POST.get('email')
        pass1=request.POST.get('password1')
        pass2=request.POST.get('password2')

        if pass1!=pass2:
            return HttpResponse("Your password and confrom password are not Same!!")
        else:

            my_user=User.objects.create_user(uname,email,pass1)
            my_user.save()
            return redirect('login')

    return render(request, "signup.html")

def Login(request):
    if request.method=='POST':
        username=request.POST.get('username')
        pass1=request.POST.get('pass')
        user=authenticate(request,username=username,password=pass1)
        if user is not None:
            login(request,user)
            return redirect('dashboard')
        else:
            return HttpResponse ("Username or Password is incorrect!!!")

    return render(request, "login.html")




def Deshboard(request):
    return render(request, "deshboard.html")

def LogoutPage(request):
    logout(request)
    return redirect('login')

def View_Profile(request):
    return render(request, "view_profile.html")

def Com_Profile(request):
    if request.method == 'POST':
        # Get the values from the form
        first_name = request.POST.get('firstNameInput', '')  # Provide an empty string as default
        last_name = request.POST.get('lastNameInput', '')  # Provide an empty string as default

        # Assuming you have a User model
        user = request.user
        user.first_name = first_name
        user.last_name = last_name
        user.save()

        #return HttpResponse ("profile update success")
        return redirect('dashboard')  # Redirect to a success page

    return render(request, "com_profile.html")

def Update_Pass(request):
    if request.method == 'POST':
        current_password = request.POST.get('currentPasswordInput')
        new_password = request.POST.get('newPasswordInput')
        confirm_password = request.POST.get('confirmPasswordInput')

        # Check if the current password is correct
        if not request.user.check_password(current_password):
            messages.error(request, 'Your current password is incorrect.')
        elif new_password != confirm_password:
            messages.error(request, 'The new passwords do not match.')
        else:
            # Change the user's password
            request.user.set_password(new_password)
            request.user.save()
            update_session_auth_hash(request, request.user)  # Update session authentication hash
            messages.success(request, 'Your password has been updated successfully.')
            return redirect('dashboard')  # Redirect to the same page after successful password change

    return render(request, "update_pass.html")




def Take_a_Plan(request):
    return render(request, "take_a_plan.html")

def Desh_Per(request):
    return render(request, "desh_per.html")

def Desh_Temp(request):
    return render(request, "desh_temp.html")




def qr_per_w_l(request):
    return render(request, "desh_per\qr_per_w_l\qr_per_w_l.html")

def qr_per_wo_l(request):
    return render(request, "desh_per\qr_per_wo_l\qr_per_wo_l.html")

def qr_temp_w_l(request):
    return render(request, "desh_temp\qr_temp_w_l\qr_temp_w_l.html")

def qr_temp_wo_l(request):
    return render(request, "desh_temp\qr_temp_wo_l\qr_temp_wo_l.html")




def Qr_Temp_Wo_l_Text(request):
    context = {}
    if request.method == "POST":
        qr_text = request.POST.get("qr_text", "")
        qr_image = qrcode.make(qr_text, box_size=15)
        qr_image_pil = qr_image.get_image()
        stream = BytesIO()
        qr_image_pil.save(stream, format='PNG')
        qr_image_data = stream.getvalue()
        qr_image_base64 = base64.b64encode(qr_image_data).decode('utf-8')
        context['qr_image_base64'] = qr_image_base64
        context['variable'] = qr_text
    return render(request, 'desh_temp/qr_temp_wo_l/text.html', context=context)

def Qr_Temp_Wo_l_Email(request):
    if request.method == 'POST':
        email_id = request.POST.get('email_id', '')
        subject = request.POST.get('subject', '')
        message = request.POST.get('message', '')

        # Generate QR Code using email ID, subject, and message
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(f"mailto:{email_id}?subject={subject}&body={message}")
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")

        # Convert the QR code image to base64
        buffered = BytesIO()
        img.save(buffered, format="PNG")
        qr_image_base64 = base64.b64encode(buffered.getvalue()).decode()

        # Render the email template with the QR code
        return render(request, 'desh_temp/qr_temp_wo_l/email.html', {'qr_image_base64': qr_image_base64})

    return render(request, 'desh_temp/qr_temp_wo_l/email.html')

def Qr_Temp_Wo_l_SMS(request):
    if request.method == 'POST':
        mobile_number = request.POST.get('mobile_number', '')
        message = request.POST.get('message', '')

        # Generate QR Code for SMS
        sms_uri = f"smsto:{mobile_number}:{message}"
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(sms_uri)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")

        # Convert the QR code image to base64
        buffered = BytesIO()
        img.save(buffered, format="PNG")
        qr_image_base64 = base64.b64encode(buffered.getvalue()).decode()

        return render(request, 'desh_temp/qr_temp_wo_l/sms.html', {'qr_image_base64': qr_image_base64})

    return render(request, 'desh_temp/qr_temp_wo_l/sms.html')

def Qr_Temp_Wo_l_Vcard(request):
    if request.method == 'POST':
        # Retrieve data from the form
        full_name = request.POST.get('full_name', '')
        email = request.POST.get('email', '')
        phone_number = request.POST.get('phone_number', '')
        company_name = request.POST.get('company_name', '')
        home_address = request.POST.get('home_address', '')
        city = request.POST.get('city', '')
        state = request.POST.get('state', '')
        country = request.POST.get('country', '')
        website_url = request.POST.get('website_url', '')

        # Create vCard text
        vcard = f"BEGIN:VCARD\n" \
                f"VERSION:3.0\n" \
                f"N:{full_name}\n" \
                f"FN:{full_name}\n" \
                f"ORG:{company_name}\n" \
                f"TEL:{phone_number}\n" \
                f"ADR:;;{home_address};{city};{state};{country};;\n" \
                f"EMAIL:{email}\n" \
                f"URL:{website_url}\n" \
                f"END:VCARD"

        # Generate QR Code using vCard data
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(vcard)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")

        # Convert the QR code image to base64
        buffered = BytesIO()
        img.save(buffered, format="PNG")
        qr_image_base64 = base64.b64encode(buffered.getvalue()).decode()

        return render(request, 'desh_temp/qr_temp_wo_l/vcard.html', {'qr_image_base64': qr_image_base64})

    return render(request, 'desh_temp/qr_temp_wo_l/vcard.html')

def Qr_Temp_Wo_l_Wifi(request):
    if request.method == 'POST':
        ssid = request.POST.get('ssid', '')
        password = request.POST.get('password', '')
        encryption_type = request.POST.get('encryption_type', '')

        wifi_data = f"WIFI:T:{encryption_type};S:{ssid};P:{password};;"

        # Generate Wi-Fi QR Code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(wifi_data)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")

        # Convert the QR code image to base64
        buffered = BytesIO()
        img.save(buffered, format="PNG")
        wifi_qr_image_base64 = base64.b64encode(buffered.getvalue()).decode()

        return render(request, 'desh_temp/qr_temp_wo_l/wi-fi.html', {'wifi_qr_image_base64': wifi_qr_image_base64})

    return render(request, 'desh_temp/qr_temp_wo_l/wi-fi.html')




def Qr_Temp_W_l_Text(request):
    if request.method == 'POST':
        qr_text = request.POST.get('qr_text', '')
        logo = request.FILES.get('logo', None)

        # Generate the QR code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(qr_text)
        qr.make(fit=True)
        qr_img = qr.make_image(fill_color="black", back_color="white")

        if logo:
            # Open and resize the uploaded logo
            logo_img = Image.open(logo)
            logo_img = logo_img.resize((50, 50))  # Adjust the size as needed

            # Calculate the position to center the logo on the QR code
            pos = ((qr_img.size[0] - logo_img.size[0]) // 2, (qr_img.size[1] - logo_img.size[1]) // 2)

            # Paste the logo onto the QR code
            qr_img.paste(logo_img, pos)

        # Convert the QR code image to base64
        from io import BytesIO
        buffer = BytesIO()
        qr_img.save(buffer, format="PNG")
        qr_image_base64 = base64.b64encode(buffer.getvalue()).decode()

        context = {
            'qr_image_base64': qr_image_base64,
            'variable': qr_text,
        }
        return render(request, 'desh_temp/qr_temp_w_l/text_w_l.html', context)

    return render(request, "desh_temp/qr_temp_w_l/text_w_l.html")

def Qr_Temp_W_l_Email(request):
    if request.method == 'POST':
        email_id = request.POST.get('email_id', '')
        subject = request.POST.get('subject', '')
        message = request.POST.get('message', '')
        logo = request.FILES.get('logo', None)

        # Generate the QR code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(f"mailto:{email_id}?subject={subject}&body={message}")
        qr.make(fit=True)
        qr_img = qr.make_image(fill_color="black", back_color="white")

        if logo:
            # Open and resize the uploaded logo
            logo_img = Image.open(logo)
            logo_img = logo_img.resize((80, 80))  # Adjust the size as needed

            # Calculate the position to center the logo on the QR code
            pos = ((qr_img.size[0] - logo_img.size[0]) // 2, (qr_img.size[1] - logo_img.size[1]) // 2)

            # Paste the logo onto the QR code
            qr_img.paste(logo_img, pos)

        # Convert the QR code image to base64
        buffer = BytesIO()
        qr_img.save(buffer, format="PNG")
        qr_image_base64 = base64.b64encode(buffer.getvalue()).decode()

        context = {
            'qr_image_base64': qr_image_base64,
            'variable': email_id,
        }
        return render(request, 'desh_temp/qr_temp_w_l/email_w_l.html', context)

    return render(request, "desh_temp/qr_temp_w_l/email_w_l.html")

def Qr_Temp_W_l_SMS(request):
    if request.method == 'POST':
        mobile_number = request.POST.get('mobile_number', '')
        message = request.POST.get('message', '')
        logo = request.FILES.get('logo', None)

        # Generate the QR code
        sms_uri = f"smsto:{mobile_number}:{message}"
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(sms_uri)
        qr.make(fit=True)
        qr_img = qr.make_image(fill_color="black", back_color="white")

        if logo:
            # Open and resize the uploaded logo
            logo_img = Image.open(logo)
            logo_img = logo_img.resize((50, 50))  # Adjust the size as needed

            # Calculate the position to center the logo on the QR code
            pos = ((qr_img.size[0] - logo_img.size[0]) // 2, (qr_img.size[1] - logo_img.size[1]) // 2)

            # Paste the logo onto the QR code
            qr_img.paste(logo_img, pos)

        # Convert the QR code image to base64
        from io import BytesIO
        buffer = BytesIO()
        qr_img.save(buffer, format="PNG")
        qr_image_base64 = base64.b64encode(buffer.getvalue()).decode()

        context = {
            'qr_image_base64': qr_image_base64,
            'variable': mobile_number,
        }
        return render(request, 'desh_temp/qr_temp_w_l/sms_w_l.html', context)

    return render(request, "desh_temp/qr_temp_w_l/sms_w_l.html")

def Qr_Temp_W_l_Vcard(request):
    if request.method == 'POST':
        # Retrieve data from the form
        full_name = request.POST.get('full_name', '')
        email = request.POST.get('email', '')
        phone_number = request.POST.get('phone_number', '')
        company_name = request.POST.get('company_name', '')
        home_address = request.POST.get('home_address', '')
        city = request.POST.get('city', '')
        state = request.POST.get('state', '')
        country = request.POST.get('country', '')
        website_url = request.POST.get('website_url', '')
        logo = request.FILES.get('logo', None)

        # Create vCard text
        vcard = f"BEGIN:VCARD\n" \
                f"VERSION:3.0\n" \
                f"N:{full_name}\n" \
                f"FN:{full_name}\n" \
                f"ORG:{company_name}\n" \
                f"TEL:{phone_number}\n" \
                f"ADR:;;{home_address};{city};{state};{country};;\n" \
                f"EMAIL:{email}\n" \
                f"URL:{website_url}\n" \
                f"END:VCARD"

        # Generate the QR code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(vcard)
        qr.make(fit=True)
        qr_img = qr.make_image(fill_color="black", back_color="white")

        if logo:
            # Open and resize the uploaded logo
            logo_img = Image.open(logo)
            logo_img = logo_img.resize((50, 50))  # Adjust the size as needed

            # Calculate the position to center the logo on the QR code
            pos = ((qr_img.size[0] - logo_img.size[0]) // 2, (qr_img.size[1] - logo_img.size[1]) // 2)

            # Paste the logo onto the QR code
            qr_img.paste(logo_img, pos)

        # Convert the QR code image to base64
        from io import BytesIO
        buffer = BytesIO()
        qr_img.save(buffer, format="PNG")
        qr_image_base64 = base64.b64encode(buffer.getvalue()).decode()

        context = {
            'qr_image_base64': qr_image_base64,
            'variable': vcard,
        }
        return render(request, 'desh_temp/qr_temp_w_l/vcard_w_l.html', context)

    return render(request, "desh_temp/qr_temp_w_l/vcard_w_l.html")

def Qr_Temp_W_l_Wifi(request):
    if request.method == 'POST':
        ssid = request.POST.get('ssid', '')
        password = request.POST.get('password', '')
        encryption_type = request.POST.get('encryption_type', '')
        logo = request.FILES.get('logo', None)

        wifi_data = f"WIFI:T:{encryption_type};S:{ssid};P:{password};;"


        # Generate the QR code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(wifi_data)
        qr.make(fit=True)
        qr_img = qr.make_image(fill_color="black", back_color="white")

        if logo:
            # Open and resize the uploaded logo
            logo_img = Image.open(logo)
            logo_img = logo_img.resize((50, 50))  # Adjust the size as needed

            # Calculate the position to center the logo on the QR code
            pos = ((qr_img.size[0] - logo_img.size[0]) // 2, (qr_img.size[1] - logo_img.size[1]) // 2)

            # Paste the logo onto the QR code
            qr_img.paste(logo_img, pos)

        # Convert the QR code image to base64
        from io import BytesIO
        buffer = BytesIO()
        qr_img.save(buffer, format="PNG")
        qr_image_base64 = base64.b64encode(buffer.getvalue()).decode()

        context = {
            'qr_image_base64': qr_image_base64,
            'variable': wifi_data,
        }
        return render(request, 'desh_temp/qr_temp_w_l/wi-fi_w_l.html', context)

    return render(request, "desh_temp/qr_temp_w_l/wi-fi_w_l.html")




def Qr_Per_Wo_l_Text(request):
    context = {}
    if request.method == "POST":
        qr_text = request.POST.get("qr_text", "")
        qr_image = qrcode.make(qr_text, box_size=15)
        qr_image_pil = qr_image.get_image()
        stream = BytesIO()
        qr_image_pil.save(stream, format='PNG')
        qr_image_data = stream.getvalue()
        qr_image_base64 = base64.b64encode(qr_image_data).decode('utf-8')
        context['qr_image_base64'] = qr_image_base64
        context['variable'] = qr_text
    return render(request, 'desh_per/qr_per_wo_l/text_per_wo_l.html', context=context)

def Qr_Per_Wo_l_Email(request):
    if request.method == 'POST':
        email_id = request.POST.get('email_id', '')
        subject = request.POST.get('subject', '')
        message = request.POST.get('message', '')

        # Generate QR Code using email ID, subject, and message
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(f"mailto:{email_id}?subject={subject}&body={message}")
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")

        # Convert the QR code image to base64
        buffered = BytesIO()
        img.save(buffered, format="PNG")
        qr_image_base64 = base64.b64encode(buffered.getvalue()).decode()

        # Render the email template with the QR code
        return render(request, 'desh_per/qr_per_wo_l/email_per_wo_l.html', {'qr_image_base64': qr_image_base64})

    return render(request, 'desh_per/qr_per_wo_l/email_per_wo_l.html')

def Qr_Per_Wo_l_SMS(request):
    if request.method == 'POST':
        mobile_number = request.POST.get('mobile_number', '')
        message = request.POST.get('message', '')

        # Generate QR Code for SMS
        sms_uri = f"smsto:{mobile_number}:{message}"
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(sms_uri)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")

        # Convert the QR code image to base64
        buffered = BytesIO()
        img.save(buffered, format="PNG")
        qr_image_base64 = base64.b64encode(buffered.getvalue()).decode()

        return render(request, 'desh_per/qr_per_wo_l/sms_per_wo_l.html', {'qr_image_base64': qr_image_base64})

    return render(request, 'desh_per/qr_per_wo_l/sms_per_wo_l.html')

def Qr_Per_Wo_l_Vcard(request):
    if request.method == 'POST':
        # Retrieve data from the form
        full_name = request.POST.get('full_name', '')
        email = request.POST.get('email', '')
        phone_number = request.POST.get('phone_number', '')
        company_name = request.POST.get('company_name', '')
        home_address = request.POST.get('home_address', '')
        city = request.POST.get('city', '')
        state = request.POST.get('state', '')
        country = request.POST.get('country', '')
        website_url = request.POST.get('website_url', '')

        # Create vCard text
        vcard = f"BEGIN:VCARD\n" \
                f"VERSION:3.0\n" \
                f"N:{full_name}\n" \
                f"FN:{full_name}\n" \
                f"ORG:{company_name}\n" \
                f"TEL:{phone_number}\n" \
                f"ADR:;;{home_address};{city};{state};{country};;\n" \
                f"EMAIL:{email}\n" \
                f"URL:{website_url}\n" \
                f"END:VCARD"

        # Generate QR Code using vCard data
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(vcard)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")

        # Convert the QR code image to base64
        buffered = BytesIO()
        img.save(buffered, format="PNG")
        qr_image_base64 = base64.b64encode(buffered.getvalue()).decode()

        return render(request, 'desh_per/qr_per_wo_l/vcard_per_wo_l.html', {'qr_image_base64': qr_image_base64})

    return render(request, 'desh_per/qr_per_wo_l/vcard_per_wo_l.html')

def Qr_Per_Wo_l_Wifi(request):
    if request.method == 'POST':
        ssid = request.POST.get('ssid', '')
        password = request.POST.get('password', '')
        encryption_type = request.POST.get('encryption_type', '')

        wifi_data = f"WIFI:T:{encryption_type};S:{ssid};P:{password};;"

        # Generate Wi-Fi QR Code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(wifi_data)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")

        # Convert the QR code image to base64
        buffered = BytesIO()
        img.save(buffered, format="PNG")
        wifi_qr_image_base64 = base64.b64encode(buffered.getvalue()).decode()

        return render(request, 'desh_per/qr_per_wo_l/wi-fi_per_wo_l.html', {'wifi_qr_image_base64': wifi_qr_image_base64})

    return render(request, 'desh_per/qr_per_wo_l/wi-fi_per_wo_l.html')




def Qr_Per_W_l_Text(request):
    if request.method == 'POST':
        qr_text = request.POST.get('qr_text', '')
        logo = request.FILES.get('logo', None)

        # Generate the QR code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(qr_text)
        qr.make(fit=True)
        qr_img = qr.make_image(fill_color="black", back_color="white")

        if logo:
            # Open and resize the uploaded logo
            logo_img = Image.open(logo)
            logo_img = logo_img.resize((50, 50))  # Adjust the size as needed

            # Calculate the position to center the logo on the QR code
            pos = ((qr_img.size[0] - logo_img.size[0]) // 2, (qr_img.size[1] - logo_img.size[1]) // 2)

            # Paste the logo onto the QR code
            qr_img.paste(logo_img, pos)

        # Convert the QR code image to base64
        from io import BytesIO
        buffer = BytesIO()
        qr_img.save(buffer, format="PNG")
        qr_image_base64 = base64.b64encode(buffer.getvalue()).decode()

        context = {
            'qr_image_base64': qr_image_base64,
            'variable': qr_text,
        }
        return render(request, 'desh_per/qr_per_w_l/text_per_w_l.html', context)

    return render(request, 'desh_per/qr_per_w_l/text_per_w_l.html')

def Qr_Per_W_l_Email(request):
    if request.method == 'POST':
        email_id = request.POST.get('email_id', '')
        subject = request.POST.get('subject', '')
        message = request.POST.get('message', '')
        logo = request.FILES.get('logo', None)

        # Generate the QR code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(f"mailto:{email_id}?subject={subject}&body={message}")
        qr.make(fit=True)
        qr_img = qr.make_image(fill_color="black", back_color="white")

        if logo:
            # Open and resize the uploaded logo
            logo_img = Image.open(logo)
            logo_img = logo_img.resize((80, 80))  # Adjust the size as needed

            # Calculate the position to center the logo on the QR code
            pos = ((qr_img.size[0] - logo_img.size[0]) // 2, (qr_img.size[1] - logo_img.size[1]) // 2)

            # Paste the logo onto the QR code
            qr_img.paste(logo_img, pos)

        # Convert the QR code image to base64
        buffer = BytesIO()
        qr_img.save(buffer, format="PNG")
        qr_image_base64 = base64.b64encode(buffer.getvalue()).decode()

        context = {
            'qr_image_base64': qr_image_base64,
            'variable': email_id,
        }
        return render(request, 'desh_per/qr_per_w_l/email_per_w_l.html', context)

    return render(request, "desh_per/qr_per_w_l/email_per_w_l.html")

def Qr_Per_W_l_SMS(request):
    if request.method == 'POST':
        mobile_number = request.POST.get('mobile_number', '')
        message = request.POST.get('message', '')
        logo = request.FILES.get('logo', None)

        # Generate the QR code
        sms_uri = f"smsto:{mobile_number}:{message}"
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(sms_uri)
        qr.make(fit=True)
        qr_img = qr.make_image(fill_color="black", back_color="white")

        if logo:
            # Open and resize the uploaded logo
            logo_img = Image.open(logo)
            logo_img = logo_img.resize((50, 50))  # Adjust the size as needed

            # Calculate the position to center the logo on the QR code
            pos = ((qr_img.size[0] - logo_img.size[0]) // 2, (qr_img.size[1] - logo_img.size[1]) // 2)

            # Paste the logo onto the QR code
            qr_img.paste(logo_img, pos)

        # Convert the QR code image to base64
        from io import BytesIO
        buffer = BytesIO()
        qr_img.save(buffer, format="PNG")
        qr_image_base64 = base64.b64encode(buffer.getvalue()).decode()

        context = {
            'qr_image_base64': qr_image_base64,
            'variable': mobile_number,
        }
        return render(request, 'desh_per/qr_per_w_l/sms_per_w_l.html', context)

    return render(request, 'desh_per/qr_per_w_l/sms_per_w_l.html')

def Qr_Per_W_l_Vcard(request):
    if request.method == 'POST':
        # Retrieve data from the form
        full_name = request.POST.get('full_name', '')
        email = request.POST.get('email', '')
        phone_number = request.POST.get('phone_number', '')
        company_name = request.POST.get('company_name', '')
        home_address = request.POST.get('home_address', '')
        city = request.POST.get('city', '')
        state = request.POST.get('state', '')
        country = request.POST.get('country', '')
        website_url = request.POST.get('website_url', '')
        logo = request.FILES.get('logo', None)

        # Create vCard text
        vcard = f"BEGIN:VCARD\n" \
                f"VERSION:3.0\n" \
                f"N:{full_name}\n" \
                f"FN:{full_name}\n" \
                f"ORG:{company_name}\n" \
                f"TEL:{phone_number}\n" \
                f"ADR:;;{home_address};{city};{state};{country};;\n" \
                f"EMAIL:{email}\n" \
                f"URL:{website_url}\n" \
                f"END:VCARD"

        # Generate the QR code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(vcard)
        qr.make(fit=True)
        qr_img = qr.make_image(fill_color="black", back_color="white")

        if logo:
            # Open and resize the uploaded logo
            logo_img = Image.open(logo)
            logo_img = logo_img.resize((50, 50))  # Adjust the size as needed

            # Calculate the position to center the logo on the QR code
            pos = ((qr_img.size[0] - logo_img.size[0]) // 2, (qr_img.size[1] - logo_img.size[1]) // 2)

            # Paste the logo onto the QR code
            qr_img.paste(logo_img, pos)

        # Convert the QR code image to base64
        from io import BytesIO
        buffer = BytesIO()
        qr_img.save(buffer, format="PNG")
        qr_image_base64 = base64.b64encode(buffer.getvalue()).decode()

        context = {
            'qr_image_base64': qr_image_base64,
            'variable': vcard,
        }
        return render(request, 'desh_per/qr_per_w_l/vcard_per_w_l.html', context)

    return render(request, 'desh_per/qr_per_w_l/vcard_per_w_l.html')

def Qr_Per_W_l_Wifi(request):
    if request.method == 'POST':
        ssid = request.POST.get('ssid', '')
        password = request.POST.get('password', '')
        encryption_type = request.POST.get('encryption_type', '')
        logo = request.FILES.get('logo', None)

        wifi_data = f"WIFI:T:{encryption_type};S:{ssid};P:{password};;"


        # Generate the QR code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(wifi_data)
        qr.make(fit=True)
        qr_img = qr.make_image(fill_color="black", back_color="white")

        if logo:
            # Open and resize the uploaded logo
            logo_img = Image.open(logo)
            logo_img = logo_img.resize((50, 50))  # Adjust the size as needed

            # Calculate the position to center the logo on the QR code
            pos = ((qr_img.size[0] - logo_img.size[0]) // 2, (qr_img.size[1] - logo_img.size[1]) // 2)

            # Paste the logo onto the QR code
            qr_img.paste(logo_img, pos)

        # Convert the QR code image to base64
        from io import BytesIO
        buffer = BytesIO()
        qr_img.save(buffer, format="PNG")
        qr_image_base64 = base64.b64encode(buffer.getvalue()).decode()

        context = {
            'qr_image_base64': qr_image_base64,
            'variable': wifi_data,
        }
        return render(request, 'desh_per/qr_per_w_l/wi-fi_per_w_l.html', context)

    return render(request, "desh_per/qr_per_w_l/wi-fi_per_w_l.html")




def Gen_Qr_Trail(request):
    return render(request, "desh_temp/qr_temp_wo_l/gen_qr_trail.html")

def Gen_Qr_Temp_W_L(request):
    return render(request, "desh_temp/qr_temp_w_l/gen_qr_temp_w_l.html")

def Gen_Qr_Per_Wo_L(request):
    return render(request, "desh_per/qr_per_wo_l/gen_qr_per_wo_l.html")

def Gen_Qr_Per_W_L(request):
    return render(request, "desh_per/qr_per_w_l/gen_qr_per_w_l.html")