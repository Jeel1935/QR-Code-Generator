"""
URL configuration for example project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from myapp import views


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.homePage),


    path('signup/', views.SignUp, name='signup'),
    path('login/', views.Login, name='login'),


    path('deshboard/', views.Deshboard, name='dashboard'),
    path('logout/',views.LogoutPage,name='logout'),
    path('view-profile/', views.View_Profile),
    path('com-profile/', views.Com_Profile),
    path('update-pass/', views.Update_Pass),


    path('take_a_plan/',views.Take_a_Plan),
    path('desh_per/', views.Desh_Per),
    path('desh_temp/', views.Desh_Temp),


    path('desh_per/qr_per_w_l/qr_per_w_l/', views.qr_per_w_l),
    path('desh_per/qr_per_wo_l/qr_per_wo_l/', views.qr_per_wo_l),
    path('desh_temp/qr_temp_w_l/qr_temp_w_l/', views.qr_temp_w_l),
    path('desh_temp/qr_temp_wo_l/qr_temp_wo_l/', views.qr_temp_wo_l),


    path('text_wo_l/',views.Qr_Temp_Wo_l_Text),
    path('email_wo_l/',views.Qr_Temp_Wo_l_Email),
    path('sms_wo_l/',views.Qr_Temp_Wo_l_SMS),
    path('vcard_wo_l/',views.Qr_Temp_Wo_l_Vcard),
    path('wi-fi_wo_l/',views.Qr_Temp_Wo_l_Wifi),


    path('text_w_l/',views.Qr_Temp_W_l_Text),
    path('email_w_l/',views.Qr_Temp_W_l_Email),
    path('sms_w_l/',views.Qr_Temp_W_l_SMS),
    path('vcard_w_l/',views.Qr_Temp_W_l_Vcard),
    path('wi-fi_w_l/',views.Qr_Temp_W_l_Wifi),


    path('text_per_wo_l/',views.Qr_Per_Wo_l_Text),
    path('email_per_wo_l/',views.Qr_Per_Wo_l_Email),
    path('sms_per_wo_l/',views.Qr_Per_Wo_l_SMS),
    path('vcard_per_wo_l/',views.Qr_Per_Wo_l_Vcard),
    path('wi-fi_per_wo_l/',views.Qr_Per_Wo_l_Wifi),


    path('text_per_w_l/',views.Qr_Per_W_l_Text),
    path('email_per_w_l/',views.Qr_Per_W_l_Email),
    path('sms_per_w_l/',views.Qr_Per_W_l_SMS),
    path('vcard_per_w_l/',views.Qr_Per_W_l_Vcard),
    path('wi-fi_per_w_l/',views.Qr_Per_W_l_Wifi),


    path('gen_qr_trail/',views.Gen_Qr_Trail),
    path('gen_qr_temp_w_l/',views.Gen_Qr_Temp_W_L),
    path('gen_qr_per_wo_l/',views.Gen_Qr_Per_Wo_L),
    path('gen_qr_per_w_l/',views.Gen_Qr_Per_W_L),
]

